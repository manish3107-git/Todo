import React from 'react'

const Header = () => {
    return (
        <>
            <div className="container-fluid" style={{ background: "blue", padding: "15px 0", color: "#fafafa" }}>
                <div className="container">
                    <h5 style={{ color: "#fafafa" }}>TODO LIST - REACT-NODEJS-MYSQL - BEGINNER</h5>
                </div>
            </div>
        </>
    )
}

export default Header